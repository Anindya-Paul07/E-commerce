import { BrowserRouter, Routes, Route } from 'react-router-dom'
import RootLayout from '@/layout/rootlayout'
import Home from '@/pages/home'
import Login from '@/pages/login'
import Register from '@/pages/register'
import Product from '@/pages/product'
import CategoryPage from '@/pages/category'
import Cart from '@/pages/cart'
import SellerApplicationPage from '@/pages/seller/apply'
import BrandDetailPage from '@/pages/brand-detail'

import AdminLayout from '@/layout/adminlayout'
import Dashboard from '@/pages/admin/dashboard'
import AdminProducts from '@/pages/admin/product'
import AdminCategory from '@/pages/admin/category'
import AdminOrdersPage from '@/pages/admin/order'
import AdminWarehouses from '@/pages/admin/warehouse'
import AdminInventory from '@/pages/admin/inventory'
import AdminSellerReviewPage from '@/pages/admin/sellers'
import AdminStorefrontCMS from '@/pages/admin/storefront'
import AdminShopCMS from '@/pages/admin/shop'
import AdminCouponsPage from '@/pages/admin/coupons'
import SellerGate from '@/components/SellerGate'
import SellerDashboard from '@/pages/seller/dashboard'
import SellerStorefrontPage from '@/pages/seller/storefront'

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route element={<RootLayout />}>
          <Route path="/" element={<Home />} />
          <Route path="/product/:slug" element={<Product />} />
          <Route path="/category/:slug" element={<CategoryPage />} />
          <Route path='/cart' element={<Cart />} />
          <Route path="/brand/:slug" element={<BrandDetailPage />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/seller/apply" element={<SellerApplicationPage />} />
          <Route
            path="/seller/dashboard"
            element={(
              <SellerGate>
                <SellerDashboard />
              </SellerGate>
            )}
          />
          <Route
            path="/seller/cms"
            element={(
              <SellerGate>
                <SellerStorefrontPage />
              </SellerGate>
            )}
          />
        </Route>

        <Route path="/admin" element={<AdminLayout />}>
          <Route index element={<Dashboard />} />
          <Route path="/admin/products" element={<AdminProducts />} />
          <Route path="/admin/categories" element={<AdminCategory />} />
          <Route path="/admin/orders" element={<AdminOrdersPage />} />
          <Route path="/admin/sellers" element={<AdminSellerReviewPage />} />
          <Route path="/admin/storefront" element={<AdminStorefrontCMS />} />
          <Route path="/admin/coupons" element={<AdminCouponsPage />} />
          <Route path="/admin/shop" element={<AdminShopCMS />} />
          <Route path="/admin/warehouses" element={<AdminWarehouses />} />
          <Route path="/admin/inventory" element={<AdminInventory />} />
        </Route>
      </Routes>
    </BrowserRouter>
  )
}
